# @noi/reset

Reset certain website styles to enhance compatibility with Noi.
