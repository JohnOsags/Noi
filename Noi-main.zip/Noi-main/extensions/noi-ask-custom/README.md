# @noi/ask-custom

The best assistant for batch asking and quick typing of prompts.
