# Noi Languages

- `en`: English
- `zh`: 简体中文
- `zh_Hant`: 繁體中文
- `ja`: 日本語
- `ko`: 한국어
- `fr`: Français
- `hu`: Hungarian
- `es`: Español
- `pt`: Português
- `ru`: Русский
- `de`: Deutsch
- `it`: Italiano
- `tr`: Türkçe
- `hu`: Magyar
